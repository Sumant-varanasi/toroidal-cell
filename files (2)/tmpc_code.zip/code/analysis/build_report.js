/**
 * build_report.js
 * ================
 * 
 * Builds the engineering report for the toroidal multipass gas cell
 * (TMPC) design study as a Word .docx.
 */
const fs   = require('fs');
const path = require('path');
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, ImageRun,
  Header, Footer, AlignmentType, PageOrientation, LevelFormat,
  TableOfContents, HeadingLevel, BorderStyle, WidthType, ShadingType,
  PageNumber, PageBreak,
} = require('docx');

const HERE   = __dirname;
const PLOTS  = path.join(HERE, '..', 'results', 'plots');
const CSVS   = path.join(HERE, '..', 'results', 'csv');
const OUTDIR = '/mnt/user-data/outputs';
fs.mkdirSync(OUTDIR, { recursive: true });
const OUT    = path.join(OUTDIR, 'TMPC_engineering_report.docx');


// ---------------- helpers ----------------
function p(text, opts = {}) {
  return new Paragraph({
    children: [new TextRun({ text, ...opts.run })],
    spacing: opts.spacing || { after: 120 },
    alignment: opts.alignment,
  });
}

function h(text, level) {
  const map = { 1: HeadingLevel.HEADING_1, 2: HeadingLevel.HEADING_2,
                3: HeadingLevel.HEADING_3 };
  return new Paragraph({
    heading: map[level],
    children: [new TextRun({ text })],
    spacing: { before: 320, after: 160 },
  });
}

function code(text) {
  return new Paragraph({
    children: [new TextRun({ text, font: 'Consolas', size: 18 })],
    spacing: { after: 80 },
  });
}

function mathBlock(text) {
  // Render simple inline-ish equations as italic monospace, set off
  // from prose. Production version would use OMML, but this is fine
  // for engineering doc readability.
  return new Paragraph({
    children: [new TextRun({ text, font: 'Cambria Math', italics: true,
                              size: 22 })],
    alignment: AlignmentType.CENTER,
    spacing: { before: 100, after: 120 },
  });
}

function bullet(text) {
  return new Paragraph({
    numbering: { reference: 'bullets', level: 0 },
    children: [new TextRun({ text })],
  });
}

function caption(text) {
  return new Paragraph({
    children: [new TextRun({ text, italics: true, size: 18 })],
    alignment: AlignmentType.CENTER,
    spacing: { after: 220 },
  });
}

function img(filename, widthIn, heightIn, captionText) {
  const fpath = path.join(PLOTS, filename);
  if (!fs.existsSync(fpath)) {
    return [p(`[missing plot: ${filename}]`)];
  }
  const ext = path.extname(filename).slice(1).toLowerCase();
  return [
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 100, after: 60 },
      children: [new ImageRun({
        type: ext === 'jpg' ? 'jpeg' : ext,
        data: fs.readFileSync(fpath),
        transformation: { width: widthIn * 96, height: heightIn * 96 },
        altText: { title: filename, description: captionText || filename,
                    name: filename },
      })],
    }),
    captionText ? caption(captionText) : new Paragraph({ children: [] }),
  ];
}

// Read CSV into array-of-objects (header row + data, quote-aware)
function splitCsvLine(line) {
  const out = [];
  let cur = '';
  let inQ = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"' ) {
      if (inQ && line[i + 1] === '"') { cur += '"'; i++; }
      else inQ = !inQ;
    } else if (ch === ',' && !inQ) {
      out.push(cur);
      cur = '';
    } else {
      cur += ch;
    }
  }
  out.push(cur);
  return out;
}

function readCsv(filename) {
  const text = fs.readFileSync(path.join(CSVS, filename), 'utf8').trim();
  const lines = text.split('\n');
  const headers = splitCsvLine(lines[0]);
  return lines.slice(1).map(line => {
    const vals = splitCsvLine(line);
    const obj = {};
    headers.forEach((h, i) => obj[h] = vals[i]);
    return obj;
  });
}

const border = { style: BorderStyle.SINGLE, size: 4, color: 'BBBBBB' };
const borders = { top: border, bottom: border, left: border, right: border };
const headShade = { fill: 'D5E8F0', type: ShadingType.CLEAR };

function makeTable(headers, rows, widths) {
  if (!widths) {
    const w = Math.floor(9360 / headers.length);
    widths = headers.map(() => w);
    widths[widths.length - 1] += 9360 - widths.reduce((a, b) => a + b, 0);
  }
  const headerRow = new TableRow({
    children: headers.map((h, i) => new TableCell({
      borders,
      width: { size: widths[i], type: WidthType.DXA },
      shading: headShade,
      margins: { top: 80, bottom: 80, left: 100, right: 100 },
      children: [new Paragraph({ children: [
        new TextRun({ text: String(h), bold: true, size: 20 })] })],
    })),
  });
  const bodyRows = rows.map(r => new TableRow({
    children: r.map((cell, i) => new TableCell({
      borders,
      width: { size: widths[i], type: WidthType.DXA },
      margins: { top: 60, bottom: 60, left: 100, right: 100 },
      children: [new Paragraph({ children: [
        new TextRun({ text: String(cell), size: 18 })] })],
    })),
  }));
  return new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: widths,
    rows: [headerRow, ...bodyRows],
  });
}

// ---------------- content ----------------
const children = [];

// --- title page ---
children.push(new Paragraph({
  alignment: AlignmentType.CENTER,
  spacing: { before: 1600, after: 240 },
  children: [new TextRun({ text: 'Toroidal Multipass Gas Cell',
                            bold: true, size: 44 })],
}));
children.push(new Paragraph({
  alignment: AlignmentType.CENTER,
  spacing: { after: 160 },
  children: [new TextRun({ text: 'Design and Optimisation Study',
                            size: 32 })],
}));
children.push(new Paragraph({
  alignment: AlignmentType.CENTER,
  spacing: { after: 600 },
  children: [new TextRun({
    text: 'CH₄ leak detection at 1.654 µm for drone-mounted operation',
    italics: true, size: 24 })],
}));
children.push(new Paragraph({
  alignment: AlignmentType.CENTER,
  spacing: { after: 100 },
  children: [new TextRun({ text: 'Aston University / IITD Abu Dhabi',
                            size: 22 })],
}));
children.push(new Paragraph({
  alignment: AlignmentType.CENTER,
  spacing: { after: 1600 },
  children: [new TextRun({ text: 'Student 3 internship — 9 June 2026',
                            size: 22 })],
}));

// --- exec summary ---
children.push(new Paragraph({ children: [new PageBreak()] }));
children.push(h('Executive summary', 1));
children.push(p(
  'A toroidal multipass cell (TMPC) is studied for compact, drone-mounted ' +
  'CH₄ detection at 1.654 µm. Eight flat ring mirrors of 25.4 mm diameter ' +
  'are arranged on a 50 mm-radius ring inside a 40 mm-tall enclosure, ' +
  'with a corner-cube top retroreflector that folds the upgoing beam back ' +
  'through the entrance aperture. The reference design (v1) achieves a ' +
  'cumulative optical path length of 20.21 m over 528 reflections — ' +
  'sufficient for 1 ppm detection of CH₄ at 1 atm when paired with a high-' +
  'reflectivity dielectric mirror coating (R ≥ 0.995). With the protected-' +
  'silver baseline (R ≈ 0.97) the path is unusable owing to cumulative ' +
  'mirror loss, motivating either a high-R dielectric coating or a shorter, ' +
  'fewer-bounce variant. Spot overlap is unavoidable in the flat-mirror ' +
  'regime at 20 m path; this is acceptable for absorption (the cell ' +
  'behaves as a diffuse-fill volume) but precludes use as an individual-' +
  'pass-resolved cell. The optimiser (SciPy/Powell, GA, PSO; three methods ' +
  'compared) recovers two regimes: an overlap-tolerant maximum at ~40 m ' +
  'path with R = 0.999, and an overlap-strict maximum at ~6 m path with ' +
  'fewer (~80) bounces. The recommended drone-deployment design uses ' +
  'curved (ROC = 2 m) mirrors with R ≥ 0.999 dielectric coatings as a next-' +
  'step refinement.'
));

// --- 1. assumptions ---
children.push(h('1. Design assumptions', 1));
const assumptions = [
  ['Wavelength', 'λ = 1.654 µm (CH₄ R(3) line, 2ν₃ band)'],
  ['Source', 'Eblana TO39 DFB diode laser, 5–10 mW, M² = 1.2'],
  ['Input waist (1/e²)', 'w₀ = 1.0 mm (collimated)'],
  ['Gas', 'CH₄ in N₂, 0.1–100 ppm, 1 atm, 293 K'],
  ['Target OPL', '20 m (effective absorption length)'],
  ['Detection limit', '1 ppm CH₄'],
  ['Ring mirrors', 'N = 8 protected-silver, Ø25.4 mm, flat (v1)'],
  ['Top retroreflector', 'Corner-cube (apex on cell axis)'],
  ['Entrance/exit', 'Single hole in mirror 0 at z = −H/2'],
  ['Closure', 'Beam returns exactly to entrance hole'],
  ['Drone constraints', 'Outer ⌀ ≤ 120 mm, internal volume ≤ 150 mL, mass-conscious'],
];
children.push(makeTable(
  ['Quantity', 'Value / source'],
  assumptions,
  [2400, 6960],
));

// --- 2. geometry ---
children.push(h('2. Geometry description', 1));
children.push(p(
  'The TMPC consists of N flat ring mirrors arranged on a horizontal ring ' +
  'of radius R, with mirror centres on the polygon vertices and surface ' +
  'normals pointing radially inward. The mirror axis is along the ring ' +
  'tangent, with the in-plane chord direction along the polygon edge and ' +
  'the height direction along the cell z-axis.'
));
children.push(...img('fig_topdown_v1.png', 4.6, 4.6,
  'Figure 2.1 — Top-down view of the v1 cell (N = 8, R = 50 mm). The first ' +
  'lap of red chords shows the in-plane ray trajectory. The entrance hole ' +
  'is the black "×" on mirror M0.'));
children.push(p(
  'Mirror k is centred at p_k = (R cos φ_k, R sin φ_k, 0) with φ_k = 2πk/N, ' +
  'and its inward normal is n_k = −(cos φ_k, sin φ_k, 0). The beam enters ' +
  'through a small hole in mirror 0 at z_entry = −H/2, propagates to ' +
  'mirror 1, then to mirror 2, etc., with a small out-of-plane component ' +
  'that lifts each successive hit-point by Δz per chord. After j_up = ' +
  'N·M/2 reflections (M half-laps) the beam reaches z = +H/2 where a ' +
  'corner-cube top retroreflector inverts the wave-vector and retraces ' +
  'the upgoing path exactly. The downgoing leg visits mirrors in the ' +
  'reverse order j_up, j_up−1, …, 1, exits through the same hole in ' +
  'mirror 0, and closes the cell.'
));

// --- 3. mathematical derivations ---
children.push(h('3. Mathematical derivations', 1));
children.push(h('3.1 Chord length and angle of incidence', 2));
children.push(p(
  'For N ring mirrors arranged on a regular polygon, the in-plane chord ' +
  'connecting adjacent mirror centres has length'));
children.push(mathBlock('L_chord = 2 R sin(π/N)'));
children.push(p(
  'and the angle of incidence at every mirror, by symmetry of the polygon, ' +
  'is the complement of the central half-angle'));
children.push(mathBlock('θ_i = π/2 − π/N'));
children.push(p(
  'For N = 8 this gives L_chord = 2·50·sin(22.5°) = 38.27 mm and ' +
  'θ_i = 67.5°. The grazing-incidence regime (large θ_i) is characteristic ' +
  'of small-N toroidal cells and has important consequences for ' +
  'astigmatism when curved mirrors are introduced (Section 4).'
));
children.push(h('3.2 Closure condition and out-of-plane tilt', 2));
children.push(p(
  'For the beam to close — i.e. return to the entrance hole on mirror 0 ' +
  'in the (x, y) plane — the number of upgoing reflections j_up must be ' +
  'a multiple of N/2. We write j_up = N·M/2 where M is the number of ' +
  'half-laps. The total reflection count is 2·j_up (excluding the top ' +
  'retro, which is folded invisibly into the OPL).'
));
children.push(p(
  'Defining the out-of-plane tilt angle α as the half-angle between the ' +
  'beam and the ring plane, the axial advance per chord is ' +
  'Δz = L_chord·tan(α). For the beam to climb from z_entry = −H/2 to the ' +
  'top retro at z = +H/2 in j_up chords,'));
children.push(mathBlock('tan(α) = H / (j_up · L_chord) = 2 H / (N · M · L_chord)'));
children.push(p('which for the v1 case (N=8, M=66, H=40 mm) gives α = 0.227° — small enough that the angle of incidence θ_i and chord-length deviations from the planar values can be neglected to leading order.'));
children.push(h('3.3 Optical path length', 2));
children.push(p(
  'The length of each chord leg, accounting for the out-of-plane component, is'));
children.push(mathBlock('L_leg = L_chord / cos(α)'));
children.push(p('and the total optical path length, summed over the upgoing and downgoing legs, is'));
children.push(mathBlock('OPL = 2 · j_up · L_leg = (N · M · L_chord) / cos(α)'));
children.push(p('For the v1 cell, OPL = 20.21 m, matching the 20 m design target.'));
children.push(h('3.4 ABCD analysis for curved mirrors', 2));
children.push(p(
  'When ring mirrors have radius of curvature ROC (concave, ROC > 0), the ' +
  'large angle of incidence θ_i ≈ 67.5° produces severe astigmatism. The ' +
  'effective focal length splits by plane:'
));
children.push(mathBlock('f_tan = ROC · cos(θ_i) / 2,    f_sag = ROC / (2 cos(θ_i))'));
children.push(p(
  'For ROC = 2 m and θ_i = 67.5°: f_tan = 383 mm, f_sag = 2613 mm — a ' +
  '6.8× ratio. The unit-cell ABCD matrix for one leg + one mirror in each ' +
  'plane is'));
children.push(mathBlock('M = [[1, 0], [−1/f, 1]] · [[1, L_leg], [0, 1]]'));
children.push(p(
  'The classic resonator stability condition |(A+D)/2| ≤ 1 applied in each ' +
  'plane separately is necessary but not sufficient for a multipass cell ' +
  '(which is open, not resonant); we additionally require the Gaussian ' +
  'mode at every reflection to be smaller than the mirror aperture. A toroidal ' +
  '(astigmatic) mirror with ROC_tan/ROC_sag = cos²(θ_i) would equalise the two ' +
  'focal lengths and restore a stigmatic mode — this is the path forward for ' +
  'a long-OPL spot-resolved design.'
));
children.push(h('3.5 Gaussian beam propagation', 2));
children.push(p(
  'For the flat-mirror v1 cell there is no in-cell focusing; the beam ' +
  'propagates as a free-space Gaussian with embedded-M² treatment:'));
children.push(mathBlock('w(s) = w₀ · √(1 + ((s − s_w) / z_R)²),  z_R = π w₀² / (M² λ)'));
children.push(p(
  'For w₀ = 1 mm, M² = 1.2, λ = 1.654 µm: z_R = 1.583 m. The beam ' +
  'divergence half-angle is θ_div = M²λ/(πw₀) = 0.632 mrad (full angle ' +
  '1.264 mrad). Over OPL = 20.21 m the beam expands to a peak 1/e² radius ' +
  'of 6.46 mm, just inside the 12.7 mm mirror aperture.'
));
children.push(p('The beam waist is conventionally placed at the centre of the path (s_w = OPL/2) so that the spot size is symmetric about the mid-path and minimised at both endpoints.'));

// --- 4. Gaussian beam analysis ---
children.push(h('4. Gaussian beam analysis', 1));
children.push(...img('fig_beam_evolution_v1.png', 6.5, 4.0,
  'Figure 4.1 — Spot radius (1/e² intensity) along the cumulative path. The ' +
  'beam starts and ends at w₀ = 1 mm; it expands to 6.46 mm at mid-path ' +
  '(red dashed line marks the D/2 = 12.7 mm mirror aperture).'));
children.push(p(
  'The beam comfortably clears the aperture at every reflection. The ' +
  'maximum 1/e² radius (6.46 mm) leaves a margin factor of 1.97× to the ' +
  'aperture, which is acceptable for clipping-loss control: the ' +
  'per-bounce clipping loss e^(−2·a²/w²) at w_max evaluates to 4.5×10⁻⁸, ' +
  'negligible compared to mirror reflectivity loss.'
));
children.push(...img('fig_spotpatterns_v1.png', 6.3, 4.7,
  'Figure 4.2 — Spot pattern on each of the eight ring mirrors. Each panel ' +
  'shows the mirror outline (rectangle, 25.4 mm × 40 mm in chord × z) and ' +
  'the overlaid Gaussian spots (red), one for every reflection on that ' +
  'mirror. With M = 66 half-laps the spots fully overlap in the z-direction, ' +
  'and the cell behaves as a diffuse absorption volume.'));
children.push(p(
  'The minimum spot separation on a single mirror, after deduplicating ' +
  'retraced upgoing/downgoing pairs, is Δz_min = 0.152 mm — far smaller ' +
  'than the 6.46 mm peak spot radius. This is the headline trade for the ' +
  'v1 design: a 20 m path with N = 8 flat mirrors necessarily means the ' +
  'individual passes are not resolved on any mirror. For methane absorption ' +
  'measurement this is benign (the integrated path-length through the gas ' +
  'is unchanged), but it precludes any pass-counting diagnostic and rules ' +
  'out single-spot photothermal techniques.'
));

// --- 5. optimisation methodology ---
children.push(h('5. Optimisation methodology', 1));
children.push(p(
  'The cell was optimised across the decision vector ' +
  'x = [R, H, M_halfLaps, w₀, R_ring] with the mirror count N held fixed ' +
  'at 8 for the headline run and swept externally as a categorical ' +
  'hyperparameter. Three optimisers were implemented in pure Python:'));
children.push(bullet('SciPy Powell — bounded local search with finite-difference gradients, started from the v1 baseline.'));
children.push(bullet('Genetic algorithm — real-coded, 40-individual population, 40 generations, tournament selection with arithmetic crossover and Gaussian mutation, seeded with the v1 baseline as one individual.'));
children.push(bullet('Particle swarm — 30 particles, 40 iterations, w = 0.7, c1 = c2 = 1.5, also seeded with the v1 baseline.'));
children.push(p(
  'Two utility regimes were studied. In the overlap-tolerant regime ' +
  '(absorption cell), the utility is U = OPL · T (path-length × ' +
  'cumulative throughput), with a soft penalty only when the beam clips ' +
  'the aperture. In the overlap-strict regime (spot-resolved cell), an ' +
  'additional penalty is applied if any two distinct spots on a single ' +
  'mirror are closer than 2.5× the local 1/e² spot radius.'
));
const optRows = readCsv('optimization_summary.csv').map(r => [
  r.regime, r.method,
  Number(r.R_mm).toFixed(1),
  Number(r.H_mm).toFixed(1),
  r.M_halfLaps,
  Number(r.w0_mm).toFixed(2),
  Number(r.R_ring).toFixed(3),
  Number(r.OPL_m).toFixed(2),
  Number(r.throughput).toFixed(3),
  Number(r.utility).toFixed(2),
]);
children.push(p('Optimiser comparison (N = 8, ROC = ∞, all units SI):'));
children.push(makeTable(
  ['regime', 'method', 'R [mm]', 'H [mm]', 'M', 'w₀ [mm]', 'R_ring',
   'OPL [m]', 'T', 'U'],
  optRows,
  [1320, 1320, 720, 720, 480, 720, 720, 1080, 720, 1560],
));
children.push(...img('fig_optimiser_compare.png', 6.5, 4.0,
  'Figure 5.1 — Optimiser comparison. In the overlap-tolerant regime ' +
  '(blue) all three methods converge near U ≈ 23 with OPL ≈ 40 m and ' +
  'R_ring = 0.999. In the overlap-strict regime (orange) the utility ' +
  'collapses because spot overlap dominates the penalty.'));
children.push(p(
  'GA and PSO outperform SciPy Powell in the overlap-tolerant regime by ' +
  '~32 % in utility, exploring the boundary R = 100 mm, H = 60 mm, ' +
  'M ≈ 66, w₀ = 2 mm — the largest practical cell that fits the drone ' +
  'envelope. In the overlap-strict regime all three methods converge to ' +
  'the same operating point at ~6 m OPL with only 80–96 reflections.'
));
children.push(...img('fig_optimiser_per_N.png', 6.5, 4.0,
  'Figure 5.2 — Optimised OPL and throughput against ring-mirror count N ' +
  '(overlap-tolerant regime, SciPy/Powell). N = 6–8 is the sweet spot for ' +
  'OPL; higher N reduces the chord length faster than reflections grow.'));

// --- 6. Python implementation ---
children.push(h('6. Python implementation', 1));
children.push(p(
  'The simulation package is structured into five modules under the ' +
  'tmpc/ namespace, each ~100–300 lines of documented Python (NumPy, ' +
  'SciPy, pandas, matplotlib):'));
children.push(bullet('geometry.py — TMPCConfig dataclass; chord/AOI/α derivations; trace_cell() ray tracer; distinct-spot deduplication; min-spot-separation and mirror-fill-fraction diagnostics.'));
children.push(bullet('gaussian.py — GaussianBeam class with complex q-parameter; ABCD matrices for free space, thin lens and off-axis curved-mirror unit cells; per-plane stability evaluation.'));
children.push(bullet('losses.py — LossModel dataclass; per-bounce mirror loss broken into reflectivity / absorption / scatter; Gaussian clipping_loss(); first-order misalignment coupling; cumulative throughput.'));
children.push(bullet('optimize.py — SciPy/Powell, real-coded GA, and PSO over the [R, H, M, w₀, R_ring] decision vector; both overlap-strict and overlap-tolerant utilities.'));
children.push(bullet('plotting.py — Matplotlib (Agg backend, no GUI) figures: top-down, spot patterns, beam evolution, throughput, sweep plots.'));
children.push(p('Four analysis scripts under analysis/ orchestrate the workflow:'));
children.push(code('01_baseline.py         v1 reference design, headline figures'));
children.push(code('02_sweeps.py           parameter sweeps (N, R, ROC, R_ring, w₀)'));
children.push(code('03_optimize.py         SciPy/Powell + GA + PSO comparison'));
children.push(code('04_generate_csvs.py    Phase 6 schema CSV exports'));

// --- 7. results tables ---
children.push(h('7. Results — parameter sweeps', 1));
function dumpSweep(filename, cols, title, headers) {
  const rows = readCsv(filename).map(r => cols.map(c => {
    const v = r[c];
    if (v === undefined || v === '') return '—';
    const n = Number(v);
    if (Number.isNaN(n)) return v;
    if (Math.abs(n) >= 1000 || (Math.abs(n) < 0.01 && n !== 0))
      return n.toExponential(2);
    if (Number.isInteger(n)) return n.toString();
    return n.toFixed(3);
  }));
  children.push(p(title));
  children.push(makeTable(headers, rows));
}

children.push(h('7.1 Mirror count N', 2));
dumpSweep('sweep_N.csv',
  ['N', 'M_halfLaps', 'n_reflections', 'OPL_m', 'transmission',
   'w_max_mm', 'min_spot_sep_mm', 'mirror_fill_frac'],
  'Sweep over ring-mirror count N at fixed R = 50 mm, R_ring = 0.99. ' +
  'Holding the total reflection count at ~528 favours small N (longer ' +
  'chords → longer OPL).',
  ['N', 'M', 'n_refl', 'OPL [m]', 'T', 'w_max [mm]', 'min sep [mm]',
   'fill']);
children.push(...img('fig_sweep_N_OPL.png', 6.2, 3.8,
  'Figure 7.1 — OPL vs N at constant reflection count.'));

children.push(h('7.2 Ring radius R', 2));
dumpSweep('sweep_R.csv',
  ['R_mm', 'OPL_m', 'transmission', 'w_max_mm', 'V_internal_mL'],
  'Sweep over ring radius R at fixed N = 8, M = 66, R_ring = 0.99. ' +
  'OPL scales linearly with R, but cell volume scales as R² and ' +
  'transmission collapses at R = 100 mm due to severe beam-clipping at ' +
  'the mirror aperture.',
  ['R [mm]', 'OPL [m]', 'T', 'w_max [mm]', 'V [mL]']);
children.push(...img('fig_sweep_R_OPL.png', 6.2, 3.8,
  'Figure 7.2 — OPL vs ring radius R.'));

children.push(h('7.3 Mirror reflectivity', 2));
dumpSweep('sweep_R_ring.csv',
  ['R_ring', 'n_reflections', 'OPL_m', 'transmission'],
  'Sweep over mirror reflectivity at fixed v1 geometry (528 reflections). ' +
  'Reflectivity dominates the design budget: from R = 0.97 to R = 0.999 ' +
  'the transmission spans seven orders of magnitude.',
  ['R_ring', 'n_refl', 'OPL [m]', 'T']);
children.push(...img('fig_sweep_Rring_T.png', 6.2, 3.8,
  'Figure 7.3 — Transmission vs mirror reflectivity at constant ' +
  '528-bounce geometry.'));
children.push(...img('fig_reflectivity_budget.png', 6.2, 3.8,
  'Figure 7.4 — Generic reflectivity budget R^n for the four candidate ' +
  'mirror grades. The dashed line marks the v1 design at n = 528 ' +
  'reflections.'));

children.push(h('7.4 Input beam waist w₀', 2));
dumpSweep('sweep_w0.csv',
  ['w0_mm', 'OPL_m', 'transmission', 'w_max_mm', 'mirror_fill_frac'],
  'Sweep over input waist w₀. Too small a waist (0.5 mm) diverges to a ' +
  '12.8 mm spot inside the cell — at the aperture limit — and clipping ' +
  'wipes out the throughput. w₀ = 1–1.5 mm is the working range.',
  ['w₀ [mm]', 'OPL [m]', 'T', 'w_max [mm]', 'fill']);
children.push(...img('fig_sweep_w0_wmax.png', 6.2, 3.8,
  'Figure 7.5 — Peak in-cell spot radius vs input waist.'));

children.push(h('7.5 Mirror curvature (ROC)', 2));
dumpSweep('sweep_ROC.csv',
  ['ROC_mm', 'stab_tangential', 'stab_sagittal', 'stable'],
  'Sweep over mirror ROC. Stability (A+D)/2 is reported per plane; all ' +
  'tested ROC values yield a stable Gaussian mode in both planes, ' +
  'though tangential and sagittal mode sizes differ by ~7× at θ_i = ' +
  '67.5° — the astigmatism that toroidal mirrors are designed to ' +
  'correct.',
  ['ROC [mm]', 'stab (tan)', 'stab (sag)', 'stable?']);
children.push(...img('fig_sweep_ROC_stability.png', 6.2, 3.8,
  'Figure 7.6 — Tangential stability parameter vs ROC.'));

children.push(h('7.6 Joint (N, R) sweep', 2));
children.push(...img('fig_heatmap_N_R_OPL.png', 6.2, 4.5,
  'Figure 7.7 — Heat-map of OPL [m] vs (N, R). Long paths concentrate ' +
  'in the upper-left (small N, large R).'));
children.push(...img('fig_heatmap_N_R_utility.png', 6.2, 4.5,
  'Figure 7.8 — Heat-map of utility (OPL × transmission) vs (N, R). The ' +
  'sweet spot collapses to a narrow ridge once throughput is factored in.'));

// --- 8. spot pattern figures ---
children.push(h('8. Spot pattern figures', 1));
children.push(p(
  'The spot pattern on each ring mirror (Figure 4.2) is the key ' +
  'diagnostic for cell occupancy. For the v1 design, every mirror is ' +
  'visited 66 times (132 hits including retraced pairs, deduplicated ' +
  'on z to give 66 distinct spots). The min-spot-separation of 0.15 mm ' +
  'and 1/e² spot radii of 6.5 mm mean the spots fully overlap on every ' +
  'mirror — the mirror-fill fraction saturates at 1.0.'));
children.push(p(
  'This is acceptable for a diffuse absorption cell but means the v1 ' +
  'cell cannot be used as a spot-counting / pass-resolved diagnostic. ' +
  'For applications that require distinct passes, the recommended ' +
  'remediation is (a) curved (toroidal) ring mirrors to refocus the ' +
  'beam at every reflection, and (b) reduction of the half-lap count ' +
  'M to ≤ 12 (giving ~80 reflections, ~6 m OPL, distinct spots).'));

// --- 9. path length ---
children.push(h('9. Path length calculations', 1));
const baseline = readCsv('baseline_summary.csv');
const blRows = baseline.map(r => {
  const v = Number(r.Value);
  let val = r.Value;
  if (!Number.isNaN(v)) {
    if (Number.isInteger(v)) val = String(v);
    else if (Math.abs(v) >= 100) val = v.toFixed(2);
    else if (Math.abs(v) >= 1) val = v.toFixed(3);
    else if (Math.abs(v) >= 0.001) val = v.toFixed(4);
    else val = v.toExponential(3);
  }
  return [r.Parameter, val, r.Units, r.Notes];
});
children.push(p('Headline v1 design quantities (computed directly by trace_cell()):'));
children.push(makeTable(['Parameter', 'Value', 'Units', 'Notes'],
                         blRows,
                         [2400, 1400, 900, 4660]));
children.push(p(
  'The traced OPL matches the closed-form derivation to better than 1 ppm ' +
  '(20.2058 m vs 20.2058 m), validating the geometric model.'));

// --- 10. loss analysis ---
children.push(h('10. Loss analysis', 1));
children.push(...img('fig_throughput_v1.png', 6.5, 4.0,
  'Figure 10.1 — Cumulative transmission vs path length for the v1 cell ' +
  '(528 reflections, w₀ = 1 mm) at four mirror reflectivities. Only ' +
  'R ≥ 0.995 yields a usable cell; R = 0.97 (protected silver) decays to ' +
  '10⁻⁷.'));
children.push(p(
  'The reflectivity budget is the dominant constraint. For 528 reflections:'));
children.push(makeTable(
  ['R per bounce', 'Survival after 528 bounces', 'Loss budget [%]',
   'Per-bounce abs [ppm]', 'Per-bounce scat [ppm]'],
  [
    ['0.970', '9.9 × 10⁻⁸', '99.999990', '12 000', '18 000'],
    ['0.990', '4.8 × 10⁻³', '99.515',    '4 000',  '6 000'],
    ['0.995', '6.96 × 10⁻²', '93.04',    '2 000',  '3 000'],
    ['0.999', '5.81 × 10⁻¹', '41.86',    '400',    '600'],
  ]));
children.push(p(
  'The per-bounce absorption / scatter split assumes the protected-silver ' +
  'breakdown (40 % absorption, 60 % scatter) for illustration; high-R ' +
  'dielectric coatings invert this ratio (scatter-dominated) but the total ' +
  'loss budget is what the design must respect.'
));
children.push(p('Clipping and coupling losses are subdominant for the v1 design:'));
children.push(bullet('Clipping: at w_max = 6.46 mm and aperture a = 12.7 mm, the per-bounce clipping loss is exp(−2 a²/w²) = 4.5 × 10⁻⁸. Negligible.'));
children.push(bullet('Coupling: assuming pointing 1σ of 50 µrad and 20 µm offset, the input-mode coupling loss is (σ_d/w₀)² + (πw₀σ_θ/λ)² ≈ 0.009 — a one-off 0.9 % insertion loss that does not compound.'));
children.push(bullet('Mirror reflectivity dominates for any practical v1 design.'));

// --- 11. recommended design ---
children.push(h('11. Recommended design', 1));
children.push(p('For the drone-mounted CH₄ leak detector at 1.654 µm, the recommended starting design is:'));
const recDesign = [
  ['Ring mirrors N', '8'],
  ['Ring radius R', '50 mm'],
  ['Cell height H', '40 mm'],
  ['Cell outer diameter', '~115 mm'],
  ['Internal volume bound', '~120 mL'],
  ['Mirror diameter D', '25.4 mm (Ø1″)'],
  ['Mirror ROC (Phase 1)', 'Flat (sourced as Thorlabs PF10-03-P01)'],
  ['Mirror ROC (Phase 2)', '2 m concave, toroidal (custom)'],
  ['Mirror coating', 'High-R dielectric (R ≥ 0.999 at 1.654 µm)'],
  ['Input waist w₀', '1.0 mm (1/e²)'],
  ['Half-laps M', '66'],
  ['Total reflections', '528 + 1 (top retro)'],
  ['Optical path length', '20.21 m'],
  ['Throughput @ R = 0.999', '~58 %'],
  ['Top retroreflector', 'Hollow corner-cube, R ≥ 0.999'],
];
children.push(makeTable(['Parameter', 'Value'], recDesign, [4000, 5360]));
children.push(p(
  'Phase 1 prototype uses the off-the-shelf Thorlabs PF10-03-P01 flat ' +
  'protected-silver mirrors to validate the geometry; the cell will run ' +
  'at greatly reduced effective path (~3–5 m worth of usable signal) ' +
  'until the high-R dielectric Phase 2 mirrors are sourced. The corner-' +
  'cube top retroreflector is sourced as a hollow (front-surface) glass ' +
  'unit with dielectric overcoat to keep R_top ≥ 0.999. ' +
  'Alignment is critical: a 50 µrad pointing budget translates to ' +
  '~3 arcsec mirror-mount stability, achievable with kinematic mounts ' +
  'but requires vibration isolation on the drone gimbal.'));

// --- 12. future improvements ---
children.push(h('12. Future improvements', 1));
children.push(bullet('Toroidal (astigmatic) mirrors with ROC_tan/ROC_sag = cos²(67.5°) ≈ 0.146 to equalise tangential and sagittal mode sizes. Compensates the 6.8× astigmatism intrinsic to grazing-incidence reflection.'));
children.push(bullet('Mid-IR variant at 3.3 µm: ~150× stronger CH₄ absorption (Q-branch fundamental), permitting a shorter cell (~3 m OPL) at the same detection limit. Requires MCT detector and ZnSe / CaF₂ optics.'));
children.push(bullet('Wavelength modulation spectroscopy (WMS) at reduced pressure (100 mbar) for sharper absorption lines and improved selectivity in the presence of water-vapour interference.'));
children.push(bullet('Active alignment using a piezo-actuated tilt on the top retro, closed-loop on a quadrant detector at the exit hole. Compensates drone vibration.'));
children.push(bullet('Field-flat mirror configuration: replace the corner-cube top with a tilted flat mirror that adds one extra in-plane lap, distributing reflections across both ends of the cell and halving the per-mirror occupancy.'));
children.push(bullet('Photothermal interferometry on a single resolved spot: only feasible with the overlap-strict (~6 m, ~80 bounces) regime and curved mirrors; would gain ~30× sensitivity at the cost of longer hardware development.'));

// --- references ---
children.push(h('References', 1));
children.push(bullet('Patent US7876443B2 — Multipass optical device and process for gas and analyte detection.'));
children.push(bullet('Gulyás G. et al. (2018), "Optically stable circular multipass cell", Opt. Express.'));
children.push(bullet('Zhang H. et al. (2022), "Design and analysis of a novel folded optical multi-pass cell", Sensors.'));
children.push(bullet('Siegman A. E. (1986), "Lasers", University Science Books — chapters on Gaussian beams and ABCD analysis.'));
children.push(bullet('HITRAN online database — CH₄ absorption cross-section at 1.654 µm.'));
children.push(bullet('Thorlabs PF10-03-P01 datasheet (protected silver, R > 97 % @ 0.45–2 µm).'));
children.push(bullet('Thorlabs CM254-1000-P01 datasheet (concave protected silver, ROC = 2 m).'));

// ---------------- build document ----------------
const doc = new Document({
  creator: 'Aston University / IITD Abu Dhabi',
  title: 'Toroidal Multipass Gas Cell Design Report',
  styles: {
    default: { document: { run: { font: 'Arial', size: 22 } } },
    paragraphStyles: [
      { id: 'Heading1', name: 'Heading 1', basedOn: 'Normal', next: 'Normal',
        quickFormat: true,
        run: { size: 32, bold: true, font: 'Arial', color: '113355' },
        paragraph: { spacing: { before: 320, after: 200 }, outlineLevel: 0 } },
      { id: 'Heading2', name: 'Heading 2', basedOn: 'Normal', next: 'Normal',
        quickFormat: true,
        run: { size: 26, bold: true, font: 'Arial', color: '225588' },
        paragraph: { spacing: { before: 220, after: 140 }, outlineLevel: 1 } },
      { id: 'Heading3', name: 'Heading 3', basedOn: 'Normal', next: 'Normal',
        quickFormat: true,
        run: { size: 22, bold: true, font: 'Arial', color: '225588' },
        paragraph: { spacing: { before: 180, after: 120 }, outlineLevel: 2 } },
    ],
  },
  numbering: {
    config: [{
      reference: 'bullets',
      levels: [{
        level: 0, format: LevelFormat.BULLET, text: '•',
        alignment: AlignmentType.LEFT,
        style: { paragraph: { indent: { left: 720, hanging: 360 } } },
      }],
    }],
  },
  sections: [{
    properties: {
      page: {
        size: { width: 12240, height: 15840 },
        margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 },
      },
    },
    headers: {
      default: new Header({ children: [new Paragraph({
        alignment: AlignmentType.RIGHT,
        children: [new TextRun({
          text: 'TMPC design study — CH₄ leak detection @ 1.654 µm',
          size: 18, italics: true, color: '666666' })],
      })] }),
    },
    footers: {
      default: new Footer({ children: [new Paragraph({
        alignment: AlignmentType.CENTER,
        children: [new TextRun({ text: 'Page ', size: 18, color: '666666' }),
                    new TextRun({ children: [PageNumber.CURRENT], size: 18,
                                   color: '666666' })],
      })] }),
    },
    children,
  }],
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync(OUT, buf);
  console.log(`Wrote ${OUT} (${buf.length} bytes)`);
});
